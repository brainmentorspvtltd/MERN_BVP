export const Output = ({message})=>{
    return (<h3>{message}</h3>)
}