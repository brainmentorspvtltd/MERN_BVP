import { Counter } from "./container/Counter";

// React - Arrow Function
const App = ()=>{
  return (<Counter/>);
}
export default App;