export const Button = ({label, cssclass, call})=>{
    const logic = ()=>{
        console.log('I am the Logic Fn');
        call(); // Parent plus or minus function will get call;
    }
    const myClass = `btn btn-${cssclass}`;
    return (<button onClick={logic} className={myClass}>{label}</button>)
}

