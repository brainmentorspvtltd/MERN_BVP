export const Output = ({val})=>{
    console.log('Output call');
    return (<h3>{val}</h3>)
}