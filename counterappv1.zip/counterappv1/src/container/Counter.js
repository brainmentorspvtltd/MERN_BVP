import React, { useState } from "react"
import { Button } from "../components/Button"
import { Output } from "../components/Output"

export const Counter = ()=>{
    const [counterValue, setCounter] = useState(0);

    const plus = ()=>{
        setCounter(counterValue + 1);
        //var newValue= counterValue + 1
        //++counterValue; counterValue = counterValue + 1
        console.log('Plus call ', counterValue);
    }
    
    const minus = ()=>{
        //--counterValue;
        setCounter(counterValue - 1);
        console.log('Minus call ', counterValue);
    }

    //let counterValue = 0; // Data 
    return (<div className='container'>
        <Output val="Counter App"/>
        <Button call={plus} cssclass='primary' label="+" /> &nbsp;
        <Button call = {minus} cssclass='danger' label="-"/>
        <Output val = {counterValue}/>
    </div>)
    //return React.createElement('div',{className:'container'},React.createElement('Button'))
}