import App from "./App";
import ReactDOM from 'react-dom';
// Bridge File - Connect App Component (Root Component) with index.html
ReactDOM.render(<App/>, document.querySelector('#root'));