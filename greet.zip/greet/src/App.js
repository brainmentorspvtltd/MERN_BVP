import logo from './logo.svg';
import './App.css';
import { Greet } from './pages/Greet';

function App() {
  return (
   <Greet/>
  );
}

export default App;
