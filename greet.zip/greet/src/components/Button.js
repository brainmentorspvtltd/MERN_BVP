export const Button = ({lbl, cssclass, fn})=>{
    return (<button onClick={fn} className = {cssclass}>{lbl}</button>)
}