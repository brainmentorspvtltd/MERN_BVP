export const Input = ({lbl, fn, val})=>{
    const placeHolder = `Type ${lbl}`;
    return (<div className = 'form-group'>
        <label>{lbl}</label>
        <input value={val} onChange={fn} type='text' className='form-control' placeholder = {placeHolder}/>
    </div>)
}