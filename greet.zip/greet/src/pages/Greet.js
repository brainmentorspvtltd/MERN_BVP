import { Button } from "../components/Button"
import { Input } from "../components/Input"
import { Output } from "../components/Output"
import {useState} from 'react';
export const Greet = ()=>{
    console.log('Greet Component Render Call');
    const [firstName, setFirstName] = useState("");
    const [lastName,setLastName] = useState("");
    const [fullName, setFullName] = useState("");
    const takeFirstName = (event)=>{
        setFirstName(event.target.value);
        //firstName = event.target.value;
        console.log('First Name call ', event.target.value);
        //setFullName("");
    }
    const takeLastName = (e)=>{
        setLastName(e.target.value);
        //lastName = e.target.value;
        console.log('Last Name call');
    }
    const clearAll = ()=>{
        setFullName("");
        setFirstName("");
        setLastName("");
    }
    const initCap = (str)=>
         str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    
    const showFullName = ()=>{
        const fullNameValue = initCap(firstName) + " "+ initCap(lastName);
        setFullName(fullNameValue); // Async 
    }

    return (<div className = 'container'>
        <Output result = "Greet App "/>
        <Input val={firstName} fn = {takeFirstName} lbl="First Name"/>
        <Input val={lastName} fn = {takeLastName} lbl="Last Name"/>
        <br/>
        <Button fn = {showFullName} cssclass="btn btn-primary" lbl= "Greet"/>
        &nbsp;
        <Button fn = {clearAll} cssclass="btn btn-danger" lbl= "Clear All"/>
        <Output result = {fullName}/>
    </div>)
}