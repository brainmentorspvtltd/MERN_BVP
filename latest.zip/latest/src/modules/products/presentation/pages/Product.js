import { Menu } from "../../../../shared/widgets/Menu"

export const Product = ()=>{
    return (<div>
        <Menu/>
    </div>);
}