const http = require('http');  
//const https = require('https');
const routes = require('./routes');
const {isStaticContent, serveStaticFile} = require('./servestatic');
const fs = require('fs');
const path = require('path');
const httpsOptions = {
    cert: fs.readFileSync(path.join(__dirname,"/cert","/cert.pem")),
    key:fs.readFileSync(path.join(__dirname,"/cert/key.pem")),
}
//const server = https.createServer(httpsOptions, handleRequestAndResponse);
const server = http.createServer( handleRequestAndResponse);

function handleRequestAndResponse(request, response){
    let url = request.url;
    console.log("Request Rec ....", url);
    if(url == '/'){
        url = '/index.html';
    }
    if(isStaticContent(url)){
        serveStaticFile(url, response);
    }
    else {
        routes.dynamicRoutes(url, request, response);
    }
//     else{
// response.write("Hello Client");
// response.end(); // Flush
//     }
}
server.listen(2222,(err)=>{
    if(err){
        console.log('Error in Server ', err);
    }
    else{
        console.log('Server Start ', server.address().port);
    }
})