//  Application Constants Define Here
module.exports = {
    ROUTES :{
        USER:{
            LOGIN :'/login',
            PROFILE:'/profile',
            DELETE:'/delete/:user'
        },
        ORDER :{
            ORDER_BOOK :'/order-book',
            ORDER_CANCEL:'/order-cancel'

        }
    }
}