 module.exports = {
    "welcome":"Welcome ",
    "invalid":"Invalid Userid or Password"
 }