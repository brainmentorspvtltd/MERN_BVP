import logo from './logo.svg';
import './App.css';
import { Gps } from './shared/widgets/Gps';
import { Menu } from './shared/widgets/Menu';
import { Product } from './modules/products/presentation/pages/Product';

function App() {
  //return (<Gps/>);
  return (<Product/>)
}

export default App;
