import { useEffect, useState } from "react"
import { API_CLIENT } from "../services/api-client";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
export const Menu = ()=>{
     const [value, setValue] = useState(0);   
     const [menus, setMenu] = useState([]); 
     const handleChange = (evt, index)=>{
            setValue(index);
     }   

    useEffect(()=>{
        const promise = API_CLIENT.get(process.env.REACT_APP_MENU_URL);
        promise.then(result=>{
            console.log('Data ', result.data.category);
            setMenu(result.data.category);
        }).catch(err=>console.log('Network Err ', err));
    },[]);
    return (<>
         <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
          {menus.map((menu,index)=><Tab key = {index} label={menu.name} />)}
          {/* <Tab label="Item One" />
          <Tab label="Item Two" />
          <Tab label="Item Three"  /> */}
        </Tabs>
    </>);
}