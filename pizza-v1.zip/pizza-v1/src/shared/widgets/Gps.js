import { nativeOperations } from "../services/native";
export const Gps = ()=>{
    const successFn = (pos)=>{
        console.log('Success .... ', pos);
    }
    const failFn = (err)=>{
        console.log('Fails ',err);
    }
    const locateLocation = ()=>{
        console.log('Call Start test...');
        nativeOperations.gps(successFn, failFn);
        console.log('call ends test...');
    }
    return <button onClick = {locateLocation}>Locate Me</button>
}