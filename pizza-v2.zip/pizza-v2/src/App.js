import logo from './logo.svg';
import './App.css';
import { Gps } from './shared/widgets/Gps';
import { Menu } from './shared/widgets/Menu';

function App() {
  //return (<Gps/>);
  return (<Menu/>)
}

export default App;
