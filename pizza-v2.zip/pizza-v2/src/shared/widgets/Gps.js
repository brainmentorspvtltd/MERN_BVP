import { useState } from "react";
import { nativeOperations } from "../services/native";
import { Map } from "./Map";
import loadingImage from '../../assets/images/loading.gif';
export const Gps = ()=>{
    const [visible, setVisible] = useState(false);
    const [loading, setLoading] = useState(false);
    const [pos, setPos] = useState(null);
    const successFn = (pos)=>{
        setVisible(true);
        setLoading(false);
        setPos(pos);
        console.log('Success .... ', pos);
    }
    const failFn = (err)=>{
        console.log('Fails ',err);
    }
    const locateLocation = ()=>{
        setLoading(true);
        console.log('Call Start test...');
        nativeOperations.gps(successFn, failFn);
        console.log('call ends test...');
    }
    return <>
    {loading?<img src={loadingImage}/>:<></>}
    {visible?<Map pos = {pos}/> 
    : <button onClick = {locateLocation}>Locate Me</button>}
   
    </>
}