import { useEffect } from "react"
import { API_CLIENT } from "../services/api-client";

export const Menu = ()=>{
    useEffect(()=>{
        const promise = API_CLIENT.get(process.env.REACT_APP_MENU_URL);
        promise.then(data=>{
            console.log('Data ', data);
        }).catch(err=>console.log('Network Err ', err));
    },[]);
}