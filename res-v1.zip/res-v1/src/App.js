 const App = ()=>{
  return (<h1>Hello React JS</h1>);
}

export const show = ()=>10;
export default App;