import ReactDOM from 'react-dom';
import  App,{show}  from './App';
ReactDOM.render(<App/>, document.querySelector('#root'));