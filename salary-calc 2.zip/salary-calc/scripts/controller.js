// Glue b/w View and Model
// Take Input from View and Give Output to View
// Call Model / Logic
window.addEventListener('load', bindEvents);
function bindEvents(){
    document.getElementById('bt')
.addEventListener('click', compute);
} 
function createPTag(){
    const pTag = document.createElement('p');
    document.getElementById('root').appendChild(pTag);
    return pTag;
}
function compute(){
    var basicSalary = document
    .getElementById('salary').value;
    salaryOperations.takeSalary(basicSalary);
    for(let key in salaryOperations){
        if(key=='basicSalary' || key =='takeSalary'){
            continue;
        }
        const pTag = createPTag();
        pTag.innerText = salaryOperations[key]();
        // document.getElementById(key)
        //  .innerText = salaryOperations[key]();
    }
    // document.getElementById('hra')
    // .innerText = salaryOperations.hra(basicSalary); 
    // document.getElementById('da')
    // .innerText = salaryOperations.da(basicSalary); 

}