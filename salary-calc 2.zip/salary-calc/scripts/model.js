// Data , Logic
const salaryOperations = {
    basicSalary : 0, // Member of Object (KEY)
    //key:value, key:value
    // hra: function(){}
    // ES6 ShortHand Way of Object Creation
    takeSalary(basicSalary){
        this.basicSalary = basicSalary;
    },
    hra(){
        return this.basicSalary * 0.50;
    },
    da(){
        return this.basicSalary * 0.20;
    },
    ta(){
        return this.basicSalary * 0.30;
    }
    /*ta(){
    
    },
    gs(){

    },
    ma(){

    },
    ns(){

    }*/
}
