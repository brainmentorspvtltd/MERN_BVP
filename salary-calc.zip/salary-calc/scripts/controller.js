// Glue b/w View and Model
// Take Input from View and Give Output to View
// Call Model / Logic
window.addEventListener('load', bindEvents);
function bindEvents(){
    document.getElementById('bt')
.addEventListener('click', compute);
} 
function compute(){
    var basicSalary = document
    .getElementById('salary').value;
    document.getElementById('hra')
    .innerText = salaryOperations.hra(basicSalary); 
    document.getElementById('da')
    .innerText = salaryOperations.da(basicSalary); 

}