window.addEventListener('load', bindEvents);
function bindEvents(){
document.getElementById('bt')
.addEventListener('click', compute);
}
function compute(){
    var basicSalary = document
    .getElementById('salary').value; 
    console.log("I am Compute...", basicSalary);
    var hra =basicSalary * 0.50;
    var da = basicSalary * 0.20;
    document.getElementById('hra')
    .innerText = hra;
    document.getElementById('da')
    .innerText = da;


}

function hra(){

}

function da(){

}
function ta(){
    
}