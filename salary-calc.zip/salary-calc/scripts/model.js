// Data , Logic
var salaryOperations = {
    //key:value, key:value
    // hra: function(){}
    // ES6 ShortHand Way of Object Creation
    hra(basicSalary){
        return basicSalary * 0.50;
    },
    da(basicSalary){
        return basicSalary * 0.20;
    },
    ta(){
    
    },
    gs(){

    },
    ma(){

    },
    ns(){

    }
}
