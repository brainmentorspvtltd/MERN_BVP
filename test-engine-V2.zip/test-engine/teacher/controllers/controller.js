// Input and Output
window.addEventListener('load', bindEvents);
function bindEvents(){
    document.getElementById('add')
    .addEventListener('click', addQuestion);
}
function addQuestion(){
    // read all fields
    const fields = ["id", "name", "optiona","optionb","optionc","optiond","score","rightans"];
    const questionObject = {}; // Create Object
    for(let  i= 0 ; i<fields.length;i++){
        questionObject[fields[i]] = document.getElementById(fields[i]).value ;
    }
    
    questionOperations.add(questionObject);
    printQuestion(questionObject);
    console.log(questionObject);
}
function markDelete(){
    // where i click (On Which Row)
    const icon = this;
    const tr = this.parentNode.parentNode;
    tr.classList.toggle('alert-danger');
 // css  (toggle)
}
function createIcon(fn){
    // <i class="fa-solid fa-trash-can"></i>
    const icon = document.createElement('i');
    icon.className = 'fa-solid fa-trash-can';
    icon.addEventListener('click',fn);
    return icon;
}

function printQuestion(questionObject){
// Row, Cells, Fill Data (Object)
const tbody = document.getElementById('questions');
const tr = tbody.insertRow();
var index = 0;
for(let key in questionObject){
    tr.insertCell(index).innerText = questionObject[key];
    index++;
}
tr.insertCell(index).appendChild(createIcon(markDelete));
}
