// CRUD Logic
const questionOperations = {
    questions:[],
    add(questionObject){
        this.questions.push(questionObject);
    },
    countMark(){
            // Marked Count (true)
    },
    
    toggleMark(){
        //Flag Toggle (Inside the QuestionObject)
    },
    remove(){

    },
    searchById(id){

    },
    sort(){

    },
    get(){

    }
}